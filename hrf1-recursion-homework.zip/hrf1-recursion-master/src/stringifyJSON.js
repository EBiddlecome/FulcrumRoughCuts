// this is what you would do if you liked things to be easy:
// var stringifyJSON = JSON.stringify;

// but you don't so you're going to write it from scratch:

//-----------------------------------------------------------

//converts value into JSON text
//stores that JSON text as a string

//takes a value (object or array)- cant use values that don't have JSON representations (ie functions, undefined)
//checks to see what kind of value it is (obj, arr, etc)


//CHECK TYPES:
//if object, determine type of object
//if object is number, return to string.
//if object is null, return null
//if object value is boolean, set conditionals to accept both and return as "true"/"false" (nonobject is "false")

//if array, iterate through array and quantify each value
//store array of results
//push resultant values into JSON string
//return string

//if regular object, determine type as object
//if null, make sure to specify null!=object- we're looking for an object with a real value
//iterate through keys in object
//if object for a given key is undefined, is a function, instruct function to "continue" to go to the next real value 
//store array of results
//push resultant key : values into JSON string
//return string



var stringifyJSON = function(obj) {

	if(Array.isArray(obj)){
		var result = [];
		for(var i=0; i<obj.length; i++){
			result.push(stringifyJSON(obj[i]));
		}
		return '['+result.join(',')+']';
	}

	if(obj && typeof obj === "object"){
		var result = [];
		for(var key in obj){
			if(obj[key] === undefined || typeof(obj[key]) === "function"){
				continue;
			}
			result.push(stringifyJSON(key)+':'+stringifyJSON(obj[key]));
		}
		return '{'+result.join(',')+'}';
	}

	if (typeof obj === "string"){
		return '"'+obj+'"';
//concatenate object with quotes on either side, so we will get the interpereted value returned		
	}
	return ''+obj;
};

