// If life was easy, we could just do things the easy way:
// var getElementsByClassName = function (className) {
//   return document.getElementsByClassName(className);
// };

// But instead we're going to implement it from scratch:
var getElementsByClassName = function(className, node){
	var nodesArray = [];
	//create an empty array to store our new values
	node = node || document.body;
//nodes are our elements, we are going to return in an array
	var components = node.className.split(' ');
	//take specific elements
	if(components.indexOf(className) >= 0 ){
		//conditonal to determine element eligbility 
			nodesArray.push(node);
			//push new values into our empty array 
		}

		for(var i = 0; i < node.children.length; i++){
			//traverse the tree
			var theResults =getElementsByClassName(className, node.children[i]);
			//set results variable equal to 
			nodesArray = nodesArray.concat(theResults);

		} 

	return nodesArray;
};
